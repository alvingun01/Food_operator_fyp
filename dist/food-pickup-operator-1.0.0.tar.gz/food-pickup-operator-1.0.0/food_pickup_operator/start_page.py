def fill_table(driver, table_no: int):
    table_no_input = driver.find_element(By.NAME, "table_no")
    table_no_input.send_keys(str(table_no))